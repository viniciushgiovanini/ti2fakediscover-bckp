# Artefatos relativos à modelagem de dados do projeto

Este diretório mantém os artefatos relatório à modelagem de dados do projeto. 

Os principais documentos a serem produzidos são:


* `script_de_banco.sql`
	* Script de criação do banco de dados.

* `diagrama entidade relacionamento`
	* Apresentar o DER em imagem vetorial para eviar perda de qualidade com renderização em resolução específica.

Demais artefatos que julgar pertinentes.