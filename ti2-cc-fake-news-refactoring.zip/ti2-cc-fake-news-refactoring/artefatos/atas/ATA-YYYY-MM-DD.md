# Ata de Reunião Semanal

## Informações
**Data/hora:** data, hora  
**Local:** local da reunião  
**Meeting Purpose:** meeting_purpose  
**Secretário:** responsável pela ata  

## Participantes
Estiveram presentes na reunião:
- Nome completo da pessoa A
- Nome completo da pessoa B
- Nome completo da pessoa C

## Pauta

Item | Descrição
---- | ----
Item de Agenda 1 | • <br>• <br>• <br>• <br>• 
Item de Agenda 2 | • <br>• <br>• <br>• <br>• 

## Notas e Discussões
Item | Quem | Anotações |
---- | ---- | ---- |
item | quem | anotações |


## Ações e pendências
| Feito (S/N)? | Item | Responsável | Data para solução |
| ---- | ---- | ---- | ---- |
| | item | quem | data |

## Outras notas e informações
N/A

