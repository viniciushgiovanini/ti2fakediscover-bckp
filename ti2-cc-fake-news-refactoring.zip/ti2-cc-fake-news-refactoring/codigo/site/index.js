const recuperaDados = () => {
    const xhr = new XMLHttpRequest();

    xhr.open('GET', 'http://localhost:5000/dados', true);

    xhr.onload = () => {
        const dados = xhr.response;
        formatarDadosPraSaida(JSON.parse(dados));
    };

    xhr.send();
}

function formatarDadosPraSaida(dados) {
    let gameBox = document.querySelector('#parte-noticia');
    let nPoints = document.querySelector('#numero-pontuacao');
    let FakeNewsData = [];
    let perguntas = dados.Perguntas;
    let respostas = dados.Respostas;

    for (let i = 0; i < perguntas.length; i++) {
        perguntas[i].veracidade = perguntas[i].veracidade.split(" ")[0];
        FakeNewsData.push({
            afterAnswerContent: respostas[i].descricao,
            content: `<div> 
                <p> ${perguntas[i].descricao}</p>
                <img alt="Imagem sendo carregada..."/>
                <label for="falsa">Fake</label>
                <input type="radio" name="veracidade" id="falsa" value="falsa">
                <label for="verdadeira">Verdadeira</label>
                <input type="radio" name="veracidade" id="verdadeira" value="verdadeira">
                <button id="getFeedback">Obter feedback</button>
            </div>`,
            isFake: (perguntas[i].veracidade === "verdadeira") ? true : false
        });
    }  
    console.log(FakeNewsData);

    // dispor elementos na div principal da pagina jogo, isso na sequencia de noticias
    nPoints.innerHTML = 0;
    let j = 0;
    gameBox.innerHTML = FakeNewsData[j].content;
    let getFeed = document.querySelector('#getFeedback');
    getFeed.addEventListener('click', () => {
        let correctAnswer = `<div id='feedbackDiv'>
                                <h3 id='correctH3'> Correto!! </h3>
                                <p id='feedDescription'> ${FakeNewsData[j].afterAnswerContent} </p>
                            </div>`;
        let wrongAnswer = `<div id='feedbackDiv'>
                                <h3 id='wrongH3'> Errado!! </h3>
                                <p id='feedDescription'> ${FakeNewsData[j].afterAnswerContent} </p>
                            </div>`;
        let nextNoticeButton = '<button id="nextNotice"> Próxima notícia </button>';
        let radioValue = document.querySelector('input[name="veracidade"]:checked').value;
        radioValue = (radioValue == 'verdadeira') ? true : false;
        console.log(radioValue);
        if (FakeNewsData[j].isFake == radioValue) {
            gameBox.innerHTML = correctAnswer + nextNoticeButton;
            nPoints.innerHTML += 500;
        } else {
            gameBox.innerHTML = wrongAnswer + nextNoticeButton;
        }
        let nextNotice = document.querySelector('#nextNotice');
        nextNotice.addEventListener('click', () => {
            gameBox.innerHTML = FakeNewsData[++j].content;
        });
    });
}

window.onload = () => {
    recuperaDados();
}