# Fake News

O projeto consiste em um jogo onde o usuário deve julgar a veracidade de uma notícia disposta na tela como forma de impulsionar sua capacidade de identificar e distinguir uma fake news de uma notícia real. Inicialmente, o usuário se depara com uma imagem ou notícia que diz respeito a alguma coisa. Então, ele deve julgar a notícia como sendo verdadeira ou falsa e escolher uma das alternativas disponíveis (Verdadeira, Fake). Logo em seguida, em caso de erro ou acerto, uma mensagem irá aparecer na tela como forma de feedback, identificando pontos que evidenciam o caráter da notícia. O jogo continua e o usuário terá que julgar mais algumas notícias.

## Alunos integrantes da equipe

* Natan Alexandre Silva do Carmo
* Vitor Artur Mota Nunes
* Vinícius Henrique Giovanini
* Nome completo do aluno 4

## Professores responsáveis

* Rodrigo Richard Gomes
* Sandro Jerônimo de Almeida
* Wladmir Cardoso Brandao

## Instruções de utilização

É necessário a instalação do nodejs e do gerenciador de pacotes yarn. Após a instalação desses, deve-se fazer o download do projeto no github. Em seguida, com um terminal aberto dentro da pasta do projeto, os seguintes comandos devem ser inseridos: * yarn install * , para instalar as dependências necessárias do projeto, e depois * yarn start * , para fazer com que o jogo abra em uma página do navegador.
